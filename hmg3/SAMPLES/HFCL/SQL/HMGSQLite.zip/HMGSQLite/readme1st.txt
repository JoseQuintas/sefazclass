Command line build:

	build.bat <prgname.prg> | <projectname.hbp>

Ide build:

	ide.bat <projectname.hbp>


